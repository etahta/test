#!/usr/bin/env python3
# -*- coding: utf-8 -*-
import binascii
from passlib.hash import bcrypt
import os
import pickle
import random
import string
import subprocess
import sys
import json
from PyQt5 import QtWidgets
from PyQt5.QtCore import Qt
from PyQt5.QtSvg import QSvgWidget
from PyQt5.QtWebEngineWidgets import QWebEngineView
from PyQt5.QtCore import QUrl
from PyQt5.QtGui import QIcon

import pyudev
import psutil
import requests


try:
    import socket
    
    s = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
    s.bind("\0eta-usb-register_gateway_notify_lock")
except socket.error as e:
    error_code = e.args[0]
    error_string = e.args[1]
    print("Process already running (%d:%s ). Exiting" % (error_code, error_string))
    sys.exit(0)


context = pyudev.Context()


class MainWindow(QtWidgets.QWidget):
    def __init__(self):
        super(MainWindow, self).__init__()
        self.setWindowTitle("Eta USB Register")

        # adjusts window size according to screen resolution
        screen = app.primaryScreen()
        screen_geometry = screen.geometry()
        self.screen_width = screen_geometry.width()
        self.screen_height = screen_geometry.height()

        """self.w1 = int(self.screen_width/6.3)
        self.h1 = int(self.screen_height/2.4)"""
        #self.resize(750, 680)

        self.setGeometry(100, 100, 735, 700)
        app_icon_path = os.path.dirname(os.path.abspath(__file__)) + "/../data/usbkayit.svg"
        self.setWindowIcon(QIcon(app_icon_path))

        # moves window to center of screen
        x = (self.screen_width - 735) // 2
        y = (self.screen_height - 700) // 2
        self.move(x, y)

        self.headers = {
            'origin': 'http://api.etap.org.tr',
        }

        self.devices = []
        self.data = {
            "tckn": "",
            "password": "",
            "eba_id": "",
            "usb_serial": "",
            "username": "",
        }
        self.parsed_data = ""
        self.token = ""

        self.login_clicked = False
        self.register_clicked = False
        self.cred_status = False
        self.mount_point = ""
        self.combobox = QtWidgets.QComboBox()

        self.stacked_widget = QtWidgets.QStackedWidget()

        first_page = QtWidgets.QWidget()
        second_page = QtWidgets.QWidget()
        third_page = QtWidgets.QWidget()
        fourth_page = QtWidgets.QWidget()
        fifth_page = QtWidgets.QWidget()
        sixth_page = QtWidgets.QWidget()

        # Required variables for the first page
        first_layout = QtWidgets.QVBoxLayout()
        first_layout.setSpacing(23)

        description_label, svg_widget = self.define_common_components("Öncelikle EBA'ya giriş yapmalısınız, bilgileriniz doğrulandıktan sonra USB'nizi ekleyebilir veya çıkarabilirsiniz.") 

        login_button = QtWidgets.QPushButton("EBA Giriş", self)
        # login_button.setFixedWidth(100)
        login_button.setStyleSheet("background-color: #104e8b; color: white;")
        login_button.clicked.connect(self.show_second_page)

        first_layout.addWidget(svg_widget, alignment=Qt.AlignCenter)
        first_layout.addWidget(description_label)
        first_layout.addWidget(login_button)

        first_layout.setAlignment(Qt.AlignCenter)
        first_page.setLayout(first_layout)

        # for second page
        self.second_layout = QtWidgets.QVBoxLayout()
        second_page.setLayout(self.second_layout)

        # for third page
        self.third_layout = QtWidgets.QVBoxLayout()
        third_page.setLayout(self.third_layout)

        # for fourth page
        self.fourth_layout = QtWidgets.QVBoxLayout()
        fourth_page.setLayout(self.fourth_layout)

        # for fifth page
        self.fifth_layout = QtWidgets.QVBoxLayout()
        fifth_page.setLayout(self.fifth_layout)
        
        # for fifth page
        self.sixth_layout = QtWidgets.QVBoxLayout()
        sixth_page.setLayout(self.sixth_layout)
        
        # add pages to QStackedWidget
        self.stacked_widget.addWidget(first_page)
        self.stacked_widget.addWidget(second_page)
        self.stacked_widget.addWidget(third_page)
        self.stacked_widget.addWidget(fourth_page)
        self.stacked_widget.addWidget(fifth_page)
        self.stacked_widget.addWidget(sixth_page)

        # footer layout
        footer_layout = QtWidgets.QHBoxLayout()
        footer_label = QtWidgets.QLabel("© TÜBİTAK BİLGEM", self)
        footer_layout.addStretch(1)
        footer_layout.addWidget(footer_label)
        footer_layout.addStretch(1)

        # about dialog
        menubar = QtWidgets.QMenuBar(self)
        # help_menu = menubar.addMenu("")
        icon = os.path.dirname(os.path.abspath(__file__)) + "/../data/info.svg"
        about_action = QtWidgets.QAction(QIcon(icon),"", self)
        about_action.triggered.connect(self.show_about_dialog)
        menubar.addAction(about_action)
        
        # main layout
        main_layout = QtWidgets.QVBoxLayout()
        main_layout.addWidget(self.stacked_widget)
        main_layout.addLayout(footer_layout)
        main_layout.setMenuBar(menubar)
        self.setLayout(main_layout)
        self.stacked_widget.setCurrentIndex(0)

    def show_second_page(self):
        print("1. Login button clicked")
        self.stacked_widget.setCurrentIndex(1)
        w2 = int(self.screen_width/3)
        h2 = int(self.screen_height/2)
        # self.resize(w2, h2)
        # self.resize(750, 680)

        self.web_view = QWebEngineView()
        self.web_view.setUrl(
            QUrl(
                "https://giris.eba.gov.tr/EBA_GIRIS/Giris?uygulamaKodu=pardus&login=teacher"
            )
        )
        self.second_layout.addWidget(self.web_view)

        result = self.web_view.urlChanged.connect(self.on_url_changed)
        if result:
            self.web_view.loadFinished.connect(self.load_finished)
        print(self.refresh_usb_devices_list())

    def on_url_changed(self, url):
        """
        It was created to detect that the URL has changed
        when the user logs in to eba and
        to ensure that the user moves on to the next page.
        """
        if "api" in url.toString():
            self.token = url.toString().split("token=")[1]
            self.login_clicked = True
            print("Login process detected!")
            return True

    def load_finished(self, result):
        try:
            if result:
                print("login_clicked:", self.login_clicked)

                if self.login_clicked:
                    print("Login page loaded successfully.")
                    self.web_view.page().toPlainText(self.handle_plain_text)
                    # self.resize(750, 680)
                else:
                    print("Login page loaded but login process not detected.")
            else:
                print("error")
        except Exception as e:
            self.stacked_widget.setCurrentIndex(2)
            print(f"Exception: {e}")
            label = QtWidgets.QLabel()
            label.setText(f"<font color='red'>EBA'ya giriş başarısız.Tekrar Deneyiniz!</font>\nException: {e}")
            self.third_layout.addWidget(label)
            self.third_layout.setAlignment(Qt.AlignCenter)

    def handle_plain_text(self, text):
        self.stacked_widget.setCurrentIndex(2)
        try:
            self.parsed_data = json.loads(text)
            #print("parsed_data", self.parsed_data)
            if self.parsed_data["msg_type"] == "Success":

                description_label, svg_widget = self.define_common_components("<font color='green'>EBA'ya başarılı bir şekilde giriş yaptınız.</font>\nŞimdi USB'nizi oluşturmak için USB Oluştur, silmek için USB Sil butonuna tıklayınız.")

                register_button = QtWidgets.QPushButton("USB Oluştur", self)
                register_button.setStyleSheet(
                    "background-color: #104e8b; color: white;"
                )
                register_button.clicked.connect(self.show_usb_register_page)

                delete_button = QtWidgets.QPushButton("USB Sil", self)
                delete_button.setStyleSheet("background-color: #B22222; color: white;")
                delete_button.clicked.connect(self.delete_button_clicked)

                self.third_layout.setSpacing(23)
                self.third_layout.addWidget(svg_widget, alignment=Qt.AlignCenter)
                self.third_layout.addWidget(description_label)
                self.third_layout.addWidget(register_button)
                self.third_layout.addWidget(delete_button)
                self.third_layout.setAlignment(Qt.AlignCenter)
            else:
                # self.description_label.setText("<font color='red'>EBA'ya giriş başarısız.Tekrar Deneyiniz!</font>")
                label = QtWidgets.QLabel(self.parsed_data["msg"])
                label.setAlignment(Qt.AlignCenter)

                description_label, svg_widget = self.define_common_components("<font color='red'>EBA'ya giriş başarısız.Tekrar Deneyiniz!</font>")
                
                self.third_layout.addWidget(svg_widget, alignment=Qt.AlignCenter)
                self.third_layout.addWidget(description_label)
                self.third_layout.addWidget(label, alignment=Qt.AlignCenter)
                self.third_layout.setAlignment(Qt.AlignCenter)
        except json.JSONDecodeError:
            print("This is not valid JSON format.")
        except Exception as e:
            print(f"An error occurred: {e}")

    def random_generate_password(self):
        length = 8
        characters = string.ascii_letters + string.digits  # + '!#$&' string.punctuation
        password = "".join(random.choice(characters) for i in range(length))
        # print(password)
        return password

    def mounted(self, parts):
        for p in psutil.disk_partitions():
            if p.device in parts:
                return p.mountpoint
        return None

    def list_removable_devices(self, context):
        devices = []
        removable_devices = [
            device for device in context.list_devices(subsystem="block")
            if device.attributes.get("removable") == b"1" and device.attributes.get("ro") == b"0"
        ]

        for device in removable_devices:
            partitions = [
                partition for partition in context.list_devices(subsystem="block", DEVTYPE="partition", parent=device)
            ]            
            
            # Create Device objects for each partition
            for partition in partitions:
                # Use the device path to find the partition device
                device_info = {                    
                    "vendor": device.get("ID_VENDOR"),
                    "model": device.get("ID_MODEL"),
                    "serial": device.get("ID_SERIAL_SHORT"),
                    "sys_path": partition.device_node,
                    "partitions": [p.device_node for p in partitions],
                    "mountpoint": self.mounted([p.device_node for p in partitions]),
                    "uuid": partition.get("ID_FS_UUID")
                }
                devices.append(device_info)

        return devices

    def refresh_usb_devices_list(self):
        for dev in self.devices:
            self.devices.remove(dev)

        self.combobox.clear()

        for d in self.list_removable_devices(context):
            self.devices.append(d)

        print("self devices size is --> " + str(len(self.devices)))

        if len(self.devices) == 0:
            return False
        else:
            for device in self.devices:
                text = f"{device['vendor']} {device['model']} on {device['sys_path']}"
                self.combobox.addItem(text)
                self.mount_point = device["mountpoint"]
            return True

    def show_usb_register_page(self):
        self.stacked_widget.setCurrentIndex(3)
        self.register_clicked = True

        if self.parsed_data["data"]["utype"] == "TEACHER":
            username = self.parsed_data["data"]["uname"]
            username = self.turkish_to_english(username)
            password = self.random_generate_password()
            user = "<b>Kullanıcı Adı: </b>" + username

            self.user_label = QtWidgets.QLabel()
            self.user_label.setText(user)
            # self.user_label.setAlignment(Qt.AlignCenter)

            password_layout = QtWidgets.QHBoxLayout()
            usb_layout = QtWidgets.QHBoxLayout()

            # password part
            self.passwd_label = QtWidgets.QLineEdit(password)
            self.passwd_label.setPlaceholderText("Password")
            self.passwd_label.setEchoMode(QtWidgets.QLineEdit.PasswordEchoOnEdit)

            # Show/hide password button
            self.toggle_button = QtWidgets.QPushButton(self)
            self.toggle_button.setCheckable(True)
            show_icon_path = os.path.dirname(os.path.abspath(__file__)) + "/../data/show.png"
            self.toggle_button.setIcon(QIcon(show_icon_path))
            self.toggle_button.setFixedWidth(25)
            self.toggle_button.clicked.connect(self.toggle_password_visibility)

            password_layout.addWidget(self.passwd_label)
            password_layout.addWidget(self.toggle_button)
            # password_layout.setAlignment(Qt.AlignCenter)

            # usbler için refresh butonu
            refresh_button = QtWidgets.QPushButton(self)
            refresh_icon_path = os.path.dirname(os.path.abspath(__file__)) + "/../data/refresh.svg"
            refresh_button.setIcon(QIcon(refresh_icon_path))
            refresh_button.setFixedWidth(25)
            refresh_button.clicked.connect(self.refresh_usb_devices_list)

            usb_layout.addWidget(self.combobox)
            usb_layout.addWidget(refresh_button)
            # usb_layout.setAlignment(Qt.AlignCenter)

            button = QtWidgets.QPushButton("Register USB", self)
            # button.setFixedWidth(100)
            button.setStyleSheet("background-color: #104e8b; color: white;")
            button.clicked.connect(self.register_usb)

            description_label, svg_widget = self.define_common_components("USB'nizi kaydederken bilgilerinizi doğru girdiğinizden emin olun.")

            self.fourth_layout.addWidget(svg_widget, alignment=Qt.AlignCenter)
            self.fourth_layout.addWidget(description_label)
            self.fourth_layout.addWidget(self.user_label)
            self.fourth_layout.addLayout(password_layout)
            self.fourth_layout.addLayout(usb_layout)
            self.fourth_layout.addWidget(button)
            self.fourth_layout.setAlignment(Qt.AlignCenter)
        else:
            label = QtWidgets.QLabel()
            label.setText("Giriş yaptığınız bilgiler öğretmene ait değil!")
            label.setAlignment(Qt.AlignCenter)

            status_label = QtWidgets.QLabel()
            status_label.setText('<font color="red">Başarısız</font>')
            status_label.setAlignment(Qt.AlignCenter)

            self.fourth_layout.addWidget(status_label, alignment=Qt.AlignCenter)
            self.fourth_layout.addWidget(label, alignment=Qt.AlignCenter)
            self.fourth_layout.setAlignment(Qt.AlignCenter)

        # back button
        back_button = QtWidgets.QPushButton("Geri")
        back_button.clicked.connect(self.go_back_third_page)
        self.fourth_layout.addWidget(back_button)
        self.fourth_layout.setAlignment(Qt.AlignCenter)

    
    def register_usb(self):
        if (
            len(self.user_label.text()) == 0
            or len(self.passwd_label.text()) == 0
            or len(self.devices) == 0
        ):
            print("Boşlukları doldurun!")
            self.warning_popup("Boşlukları doldurun!")
        else:
            self.stacked_widget.setCurrentIndex(4)

            tckno = self.parsed_data["data"]["tckn"]
            eba_id = self.parsed_data["data"]["uid"]
            password = self.passwd_label.text()
            username = self.parsed_data["data"]["uname"]
            username = self.turkish_to_english(username)
            usb_uuid = str(
                self.devices.__getitem__(self.combobox.currentIndex())["uuid"]
            )
            text = ""

            self.data["tckn"] = tckno
            self.data["eba_id"] = eba_id
            self.data["password"] = password
            self.data["username"] = username
            self.data["usb_serial"] = usb_uuid
            
            status = False
            self.fifth_layout.setSpacing(23)
            
            try:
                password_url = "https://giris.eba.gov.tr/EBA_GIRIS/UsbPasswordChangerV7"

                password_data = {
                    "authCode": self.token,
                    "newPass": password,
                    "repPass": password,
                    "user_tckn": tckno
                }
                
                r = requests.post(url=password_url, data=password_data, headers=self.headers)
                print("password changer status code:", r.status_code)
                print(r.text)

                if r.status_code == 200:
                    url = "https://giris.eba.gov.tr/EBA_GIRIS/RegisterUsbUser"
                    r = requests.post(url=url, json=self.data, headers=self.headers)
                    print("register usb status code:", r.status_code)
                    
                    if r.status_code == 200:
                        result_code = r.json()["resultCode"]
                        result_text = r.json()["resultText"]
                        code = str(result_code).split(".")[1]

                        print("result_code", result_code)
                        print("result_text", result_text)

                        if code == "001":
                            print("register success")

                            self.data.clear()

                            self.data["eba_id"] = eba_id
                            self.data["username"] = username
                            self.data["usb_serial"] = usb_uuid
                            self.data["password"] = bcrypt.hash(password)
                            print(bcrypt.verify(password, self.data["password"]))
                            
                            json_data = json.dumps(self.data)                            
                            device = self.devices.__getitem__(self.combobox.currentIndex())

                            if self.writeCredentials(
                                device, binascii.hexlify(json_data.encode("utf8"))
                            ):
                                print("usb ye bilgiler kaydedildi.")
                                text = "USB'ye bilgiler başarılı bir şekilde kaydedildi."
                                status = True
                            elif self.cred_status:
                                print("usb daha önce kaydedilmiş")
                                text = "usb daha önce kaydedilmiş"
                                status = False
                            else:
                                print("usb ye bilgiler yazilamadi.")
                                text = "USB'ye bilgiler kaydedilemedi."
                                status = False

                        elif code == "003":
                            text = "USB parolası doğru değil\n"
                            status = False
                        elif code == "017":
                            text = (
                                "Gönderdiğiniz bilgileri kontrol ediniz.\n"
                                + result_code
                                + result_text
                            )
                            status = False
                        else:
                            status = False
                            print("unsuccessful", code)
                            text = "USB kaydedilemedi."
                        
                        label = QtWidgets.QLabel()
                        label.setText(text)
                        label.setAlignment(Qt.AlignCenter)

                        status_label = QtWidgets.QLabel()
                        if status:
                            status_label.setText('<font color="green">Başarılı</font>')
                        else:
                            status_label.setText('<font color="red">Başarısız</font>')
                        status_label.setAlignment(Qt.AlignCenter)

                        description_label, svg_widget = self.define_common_components(text)
                        self.fifth_layout.addWidget(svg_widget, alignment=Qt.AlignCenter)
                        self.fifth_layout.addWidget(status_label, alignment=Qt.AlignCenter)
                        self.fifth_layout.addWidget(description_label)
                        self.fifth_layout.setAlignment(Qt.AlignCenter)
                else:
                    print(r.text)
                    label = QtWidgets.QLabel(r.text)
                    description_label, svg_widget = self.define_common_components("Servise Ulaşılamıyor.")
                    self.fifth_layout.addWidget(svg_widget, alignment=Qt.AlignCenter)
                    self.fifth_layout.addWidget(description_label)
                    self.fifth_layout.addWidget(label)
                    self.fifth_layout.setAlignment(Qt.AlignCenter)
            except Exception as e:
                print("Error:", e)
                label = QtWidgets.QLabel()
                label.setText(f"Error: {e}")
                label.setAlignment(Qt.AlignCenter)
                
                status_label = QtWidgets.QLabel()
                status_label.setText('<font color="red">Başarısız</font>')
                status_label.setAlignment(Qt.AlignCenter)

                self.fifth_layout.addWidget(status_label, alignment=Qt.AlignCenter)
                self.fifth_layout.addWidget(label, alignment=Qt.AlignCenter)
                self.fifth_layout.setAlignment(Qt.AlignCenter)

            # back button
            if status:
                back_button = QtWidgets.QPushButton("Kapat")
                back_button.setStyleSheet("background-color: #B22222; color: white;")
                back_button.clicked.connect(self.close)
            else:
                back_button = QtWidgets.QPushButton("Geri")
                back_button.clicked.connect(self.go_back_fourth_page)
            self.fifth_layout.addWidget(back_button)
            self.fifth_layout.setAlignment(Qt.AlignCenter)


    def delete_button_clicked(self):
        self.warning_popup("Emin misiniz?")

    def delete_usb(self):
        self.stacked_widget.setCurrentIndex(5)

        description_label, svg_widget = self.define_common_components("USB'nin silinip silinmediğini kontrol edin")
        self.sixth_layout.addWidget(svg_widget, alignment=Qt.AlignHCenter)
        self.sixth_layout.addWidget(description_label, alignment=Qt.AlignHCenter)
        self.sixth_layout.setSpacing(23)

        url = "https://giris.eba.gov.tr/EBA_GIRIS/DeleteUsbUser"
        tckno = self.parsed_data["data"]["tckn"]

        delete_data = {"tckn": tckno}
        try:
            r = requests.post(url=url, params=(delete_data))
            print("delete usb status code:", r.status_code)

            if r.status_code == 200:
                result_code = r.json()["resultCode"]
                result_text = r.json()["resultText"]
                code = str(result_code).split(".")[1]

                print(result_code)
                print(result_text)

                text, text2 = "", ""

                status_label = QtWidgets.QLabel()
                if code == "001":
                    print("success")
                    text = "USB başarılı bir şekilde silindi"
                    status_label.setText('<font color="green">Başarılı</font>')

                    if len(self.devices) != 0 and self.mount_point != None:
                        print("device mountpoint", self.mount_point)
                        file_path = os.path.join(self.mount_point,".credentials")

                        if os.path.exists(file_path):
                            os.remove(file_path)
                            print("credential dosyası silindi.")
                            text2 = "USB'yi tekrar kullanabilirsiniz."
                    else:
                        print("USB'yi formatlamayı unutmayınız!")
                        text2 = "USB'yi formatlamayı unutmayınız!"
                elif code == "006":
                    text = "USB daha önce eklenmemiş\n"
                    status_label.setText('<font color="red">Başarısız</font>')
                else:
                    print("unsuccessful", code)
                    text = "USB silinmesi başarısız oldu." + result_code + result_text
                    status_label.setText('<font color="red">Başarısız</font>')

                label1 = QtWidgets.QLabel()
                label1.setText(text)
                #label1.setAlignment(Qt.AlignCenter)

                label2 = QtWidgets.QLabel()
                label2.setText(text2)
                #label2.setAlignment(Qt.AlignCenter)

                self.sixth_layout.addWidget(status_label, alignment=Qt.AlignCenter)
                self.sixth_layout.addWidget(label1, alignment=Qt.AlignCenter)
                self.sixth_layout.addWidget(label2, alignment=Qt.AlignCenter)
                self.sixth_layout.setAlignment(Qt.AlignCenter)

        except Exception as e:
            print("Error: ", e)
            label = QtWidgets.QLabel()
            label.setText(f"Error: {e}")
            label.setWordWrap(True)
            
            status_label = QtWidgets.QLabel()     
            status_label.setText('<font color="red">Başarısız</font>')

            self.sixth_layout.addWidget(status_label, alignment=Qt.AlignCenter)
            self.sixth_layout.addWidget(label, alignment=Qt.AlignCenter)
            self.sixth_layout.setAlignment(Qt.AlignCenter)

        # back button
        back_button = QtWidgets.QPushButton("Geri")
        back_button.clicked.connect(self.go_back_third_page)
        self.sixth_layout.addWidget(back_button)
        self.sixth_layout.setAlignment(Qt.AlignCenter)
    
    def define_common_components(self,text):
        description_label = QtWidgets.QLabel()
        description_label.setStyleSheet(
            """
            QtWidgets.QLabel {
                font: 17px;
                text-align: center;
            }
        """
        )
        description_label.setText(text)
        description_label.setWordWrap(True)
        description_label.setAlignment(Qt.AlignCenter)
        
        #svg part
        svg_path = os.path.dirname(os.path.abspath(__file__)) + "/../data/usbkayit.svg"
        svg_widget = QSvgWidget(svg_path, self)
        svg_widget.setFixedSize(256, 256)

        return description_label, svg_widget

    def go_back_third_page(self):
        self.clear_layout(self.sixth_layout)
        self.clear_layout(self.fourth_layout)
        self.stacked_widget.setCurrentIndex(2)
        self.register_clicked = False
    
    def go_back_fourth_page(self):
        self.clear_layout(self.fifth_layout)
        self.stacked_widget.setCurrentIndex(3)
    
    def clear_layout(self, layout):
        # Clears all existing widgets in the layout.
        while layout.count():
            item = layout.takeAt(0)
            widget = item.widget()
            if widget is not None:
                widget.deleteLater()

    def writeCredentials(self, device, obj):
        r = False
        print("device ", device, "obj ", obj)
        try:
            r = False

            if device["mountpoint"] != None:
                mount_path = device["mountpoint"]
            else:
                mount_path = "etap-%s" % os.getuid()
                ret = subprocess.call(
                    ["pmount", "-As", device["partitions"][0], mount_path]
                )
                if not ret == 0:
                    print("pmount failed with %d, exiting...", ret)
                mount_path = "/media/%s" % mount_path

            print("Mount path is %s" % mount_path)

            credentials_file = "%s/%s" % (mount_path, ".credentials")
            print("Credentials file is %s" % credentials_file)

            if os.path.exists(credentials_file):
                self.cred_status = True
                return False
            else:
                print("self.cred_status",self.cred_status)

            try:
                with open(credentials_file, "wb") as f:
                    print("Trying to write the object to the file")
                    pickle.dump(obj, f, pickle.HIGHEST_PROTOCOL)
                    f.flush()
                    f.close()
                    r = True
            except Exception as e:
                r = False
                print(e)

            if r:
                print("Pumounting %s" % mount_path)
                try:
                    subprocess.check_output(["pumount", mount_path])
                except Exception as e:
                    print(e)
        except Exception as ex:
            print(ex)
        return r

    def turkish_to_english(self, text):
        replacements = {
            "ç": "c",
            "Ç": "C",
            "ğ": "g",
            "Ğ": "G",
            "ı": "i",
            "İ": "I",
            "ö": "o",
            "Ö": "O",
            "ş": "s",
            "Ş": "S",
            "ü": "u",
            "Ü": "U",
        }

        for tr_char, en_char in replacements.items():
            text = text.replace(tr_char, en_char)

        return text.lower().replace(" ", "")

    def toggle_password_visibility(self):
        if self.passwd_label.echoMode() == QtWidgets.QLineEdit.Password:
            self.passwd_label.setEchoMode(QtWidgets.QLineEdit.Normal)
            hide_icon_path = os.path.dirname(os.path.abspath(__file__)) + "/../data/hide.png"
            self.toggle_button.setIcon(QIcon(hide_icon_path))
        else:
            self.passwd_label.setEchoMode(QtWidgets.QLineEdit.Password)
            show_icon_path = os.path.dirname(os.path.abspath(__file__)) + "/../data/show.png"
            self.toggle_button.setIcon(QIcon(show_icon_path))

    def warning_popup(self, text):
        msg = QtWidgets.QMessageBox()
        msg.setIcon(QtWidgets.QMessageBox.Information)
        msg.setText(text)
        msg.setWindowTitle("Warning!")

        if self.register_clicked:
            msg.setStandardButtons(QtWidgets.QMessageBox.Ok)
        else:
            msg.setStandardButtons(QtWidgets.QMessageBox.Yes | QtWidgets.QMessageBox.No)
        result = msg.exec_()

        if result == QtWidgets.QMessageBox.Yes:
            self.delete_usb()
        elif result == QtWidgets.QMessageBox.No:
            self.stacked_widget.setCurrentIndex(2)

    def show_about_dialog(self):
        # About dialog oluştur
        dialog = QtWidgets.QDialog(self)
        dialog.setWindowTitle("Hakkında")
        dialog.setWindowFlags(dialog.windowFlags() & ~Qt.WindowContextHelpButtonHint)

        layout = QtWidgets.QVBoxLayout()

        layout.setContentsMargins(20, 20, 20, 20)
        layout.setSpacing(10)
        layout.setAlignment(Qt.AlignCenter)

        # add app icon
        icon_label = QtWidgets.QLabel(dialog)
        icon_path = os.path.dirname(os.path.abspath(__file__)) + "/../data/usbkayit.svg"
        icon = QIcon(icon_path)
        pixmap = icon.pixmap(128, 128)
        icon_label.setPixmap(pixmap)
        icon_label.setAlignment(Qt.AlignCenter)

        # app name and version
        app_name_label = QtWidgets.QLabel("<h3>Eta USB Kayıt</h3>", dialog)
        app_name_label.setAlignment(Qt.AlignCenter)

        version_label = QtWidgets.QLabel("Sürüm: 1.0.2", dialog)
        version_label.setAlignment(Qt.AlignCenter)

        app_info_label = QtWidgets.QLabel("Eta USB Kayıt uygulaması USB ile login olabilmeniz için USBleri kaydeder")
        app_info_label.setAlignment(Qt.AlignCenter)
        app_info_label.setWordWrap(True)

        website_label = QtWidgets.QLabel("<a href='www.pardus.org.tr'>Website</a>", dialog)
        website_label.setAlignment(Qt.AlignCenter)

        copyright_label = QtWidgets.QLabel("© TÜBİTAK BİLGEM", dialog)
        copyright_label.setAlignment(Qt.AlignCenter)
        copyright_label.setStyleSheet(
            """
            QtWidgets.QLabel {
                font-size: 12px;
            }
            """
        )

        # developer info
        """developer_label = QtWidgets.QLabel("Geliştirici: Büşra ÇAĞLIYAN", dialog)
        developer_label.setAlignment(Qt.AlignCenter)"""

        # license
        license_label = QtWidgets.QLabel("This program comes with absolutely no warranty.See the <a href=\"https://www.gnu.org/licenses/gpl-3.0.html\">GNU General Public License, version 3 or later</a> for details.", dialog)
        license_label.setStyleSheet(
            """
            QtWidgets.QLabel {
                font-size: 12px;
            }
            """
        )
        license_label.setAlignment(Qt.AlignCenter)
        license_label.setWordWrap(True)

        button_box = QtWidgets.QDialogButtonBox(QtWidgets.QDialogButtonBox.Ok, dialog)
        button_box.accepted.connect(dialog.accept)

        # Layout'a öğeleri ekle
        layout.addWidget(icon_label)
        layout.addWidget(app_name_label)
        layout.addWidget(version_label)
        layout.addWidget(app_info_label)
        layout.addWidget(website_label)
        layout.addWidget(copyright_label)
        # layout.addWidget(developer_label)
        layout.addWidget(license_label)
        layout.addWidget(button_box)

        dialog.setLayout(layout)
        dialog.setFixedSize(450, 390)

        # show dialog
        dialog.exec_()



if __name__ == "__main__":
    app = QtWidgets.QApplication(sys.argv)
    main_window = MainWindow()
    main_window.show()
    sys.exit(app.exec_())
