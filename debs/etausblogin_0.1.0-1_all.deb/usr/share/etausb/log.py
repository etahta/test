import sys
import os

if os.path.exists("/etc/etausb.debug"):
    print=print
else:
    def print(*args, **kargs):
        return
