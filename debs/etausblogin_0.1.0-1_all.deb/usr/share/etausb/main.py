#/usr/bin/env python3
import os
import sys
import pickle

import traceback

import threading

from log import print

sys.path.insert(0,os.path.dirname(__file__))


#sys.stdout = open("/var/log/etausb.log","w")
#sys.stderr = open("/var/log/etausb.log","w")


print("##### Starting Eta Usb Login #####")

import service


os.makedirs("/run/etausb/", exist_ok=True)

if os.path.exists("/run/etausb/trigger"):
    os.remove("/run/etausb/trigger")
os.mkfifo("/run/etausb/trigger")

while True:
    with open("/run/etausb/trigger", "rb") as f:
        try:
            udata = pickle.load(f)
            print(udata["DEVNAME"])
            th = threading.Thread(target=service.listen, args=[udata])
            th.start()
        except Exception as e:
            print(traceback.format_exc())

