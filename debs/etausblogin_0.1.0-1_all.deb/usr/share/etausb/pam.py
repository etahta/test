import json
import os, sys

from log import print

#sys.stdout = open("/var/log/etausb.log","a")
#sys.stderr = open("/var/log/etausb.log","a")

def allow_user(name):
    print("########")
    print("Allowed pam user:", name)
    os.makedirs("/run/etausb", exist_ok=True)
    with open("/run/etausb/user", "w") as f:
        f.write(name)
        f.flush()

def lightdm_trigger(name):
    print("########")
    print("Lightdm trigger", name)
    if not os.path.exists("/var/lib/lightdm/pardus-greeter"):
        return
    with open("/var/lib/lightdm/pardus-greeter", "w") as f:
        data = {}
        data["username"] = name
        data["password"] = ""
        f.write(json.dumps(data))
        f.flush()

def lightdm_print(msg, *msgs):
    print("########")
    print("Lightdm send message", msg, msgs)
    if not os.path.exists("/var/lib/lightdm/pardus-greeter"):
        return
    with open("/var/lib/lightdm/pardus-greeter", "w") as f:
        data = {}
        data["message"] = str(msg)
        for m in msgs:
            data["message"] += " " + str(m)
        f.write(json.dumps(data))
        f.flush()
