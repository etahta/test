#!/usr/bin/env python3
import os
import sys
import time
import json
import shutil

#sys.stdout = open("/var/log/etausb.log","a")
#sys.stderr = open("/var/log/etausb.log","a")

sys.path.insert(0,os.path.dirname(__file__))

import usb
import credentials
import user
import pam

from log import print

def listen(udata):
    if udata["ACTION"] == "add":
        return add_event(udata)
    elif udata["ACTION"] == "remove":
        return remove_event(udata)

def remove_event(udata):
    print("######## {} ########".format(time.time()))
    uuid = None
    if "ID_FS_UUID" in udata:
        uuid = udata["ID_FS_UUID"]
    for id in os.listdir("/run/user/"):
        # check uuid is same
        if uuid != None:
            if os.path.isfile("/run/etausb/{}/credentials".format(id)):
                with open("/run/etausb/{}/credentials".format(id), "rb") as f:
                    data = credentials.read(f.read())
                    if "usb_serial" not in data:
                        continue
                    if data["usb_serial"] != uuid:
                        continue
                    if os.path.isdir("/run/etausb/{}/".format(id)):
                        shutil.rmtree("/run/etausb/{}/".format(id))
        # trigger agent
        if os.path.isdir("/run/user/{}/etausb/".format(id)):
            print("UID: "+id)
            for pid in os.listdir("/run/user/{}/etausb/".format(id)):
                # check agent is running
                if os.path.isdir("/proc/{}".format(pid)):
                    print("PID: "+pid)
                    with open("/run/user/{}/etausb/{}".format(id, pid), "w") as f:
                        f.write("1")
                        f.flush()
                else:
                    print("Remove pid: "+pid)
                    os.remove("/run/user/{}/etausb/{}".format(id, pid))


def add_event(udata):
    print(udata["DEVNAME"])
    print("######## {} ########".format(time.time()))
    # Read data from usb
    part = os.path.basename(udata["DEVNAME"])
    #ctx, part = usb.get_file(".credentials")
    ctx = usb.mount_and_check(part, ".credentials")
    uuid = usb.get_uuid(part)
    data = credentials.read(ctx)
    # Check data is valid
    if data == None:
        print("########")
        print("Invalid data:")
        return False
    # Check matching usb uuid and credential uuid
    if "usb_serial" in data:
        if data["usb_serial"] != uuid:
            print("########")
            pam.lightdm_print("Usb serial does not match")
            return False
    else:
        return False
    # check from eba
    if not user.check_eba(data["eba_id"], data["usb_serial"]):
        pam.lightdm_print("Eba Authentication Failed")
        return False
    # Check data has username and hash
    if "username" not in data or "password" not in data:
        print("########")
        pam.lightdm_print("Failed to create user.")
        print("username not found in data")
        return False
    # Check user exist and create
    user.create_user(data["username"], data["password"])
    # Write credential
    uid = user.find_uid(data["username"])
    os.makedirs("/run/etausb/{}/".format(uid), exist_ok=True)
    with open("/run/etausb/{}/credentials".format(uid), "wb") as f:
        print("########")
        print("Copy Credential")
        f.write(ctx)
        f.flush()
    os.chmod("/run/etausb/{}".format(uid), 0o700)
    os.chown("/run/etausb/{}".format(uid), int(uid), 0)
    # Write pam user
    pam.allow_user(data["username"])
    pam.lightdm_trigger(data["username"])
    return True
