import subprocess
import sys
import requests

#sys.stdout = open("/var/log/etausb.log","a")
#sys.stderr = open("/var/log/etausb.log","a")

from log import print

def is_valid_user(user):
    print("########")
    print("Check User:", user)
    with open("/etc/passwd","r") as f:
        for line in f.read().split("\n"):
            if user == line.split(":")[0]:
                return True
    return False

def create_user(user, hash):
    if is_valid_user(user):
        return update_passwd(user, hash)
    print("########")
    print("Create user:",user, hash)
    sp = subprocess.run(
        ["useradd", "-p", hash, "-s" , "/bin/bash", "-m", user]
    )
    return sp.returncode == 0

def update_passwd(user, hash):
    print("########")
    print("Update user:",user, hash)
    sp = subprocess.run(
        ["usermod", "-p", hash, user]
    )
    return sp.returncode == 0

def check_eba(eba_id, usb_serial):
    try:
        url = "https://giris.eba.gov.tr/EBA_GIRIS/GetUsbUser"
        body = {"eba_id": eba_id, "usb_serial": usb_serial}
        x = requests.post(url, json = body)
        print(x.text)
        return "EBA.001" in x.text
    except:
        return False

def find_uid(user):
    with open("/etc/passwd","r") as f:
        for line in f.read().split("\n"):
            data = line.split(":")
            if data[0] == user:
                return data[2]
    return None